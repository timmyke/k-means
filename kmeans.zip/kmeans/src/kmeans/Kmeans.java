package kmeans;

import clusterer.test.Testi;

/**
 *
 * @author timi
 */
public class Kmeans {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Testi.main(args);
    }

}
